Afterlife Kit

This zip contains the Codex skills used by the Afterlife site:
- arweave-turbo-fetch
- arweave-turbo-save

Install (typical):
1) Unzip.
2) Copy skills into your Codex skills directory (usually ~/.codex/skills):
   cp -R ./afterlife-kit/skills/* ~/.codex/skills/
3) Install deps for each skill:
   cd ~/.codex/skills/arweave-turbo-fetch && npm install
   cd ~/.codex/skills/arweave-turbo-save  && npm install

Notes:
- Do NOT commit or share your .env / wallet material (ARWEAVE_JWK_JSON).
- You still need to set env vars like TURBO_API_URL when publishing.
