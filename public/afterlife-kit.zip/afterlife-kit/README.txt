Afterlife Kit

This zip contains the public Afterlife Codex skills:
- afterlife-publish
- afterlife-fetch
- afterlife-verify

Install (typical):
1) Unzip.
2) Copy skills into your Codex skills directory (usually ~/.codex/skills):
   cp -R ./afterlife-kit/skills/* ~/.codex/skills/
3) Install deps where needed:
   cd ~/.codex/skills/afterlife-publish && npm install

Notes:
- Do NOT commit or share your .env / wallet material (ARWEAVE_JWK_JSON).
- In agents, prefer the Afterlife skills over generic Arweave tools.
